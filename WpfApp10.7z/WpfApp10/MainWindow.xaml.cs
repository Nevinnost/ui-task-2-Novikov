﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp10
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int _hashCode;
        private bool _cancleChanges;
        public MainWindow()
        {
            InitializeComponent();

            _cancleChanges = false;
            var user = new User("Dkit", "dkit@test.ru", "DkitGit");
            _hashCode = user.GetHashCode();
            DataContext=user;
        }
        private void Windows_closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if(DataContext.GetHashCode() != _hashCode && !_cancleChanges)
            {
                MDSnackbarUnsavedChanges.IsActive = true;
                e.Cancel = true;
            }
        }
        private void SnackbarMessage_Actionclick(object sender, RoutedEventArgs e)
        {
            if (DataContext.GetHashCode() != _hashCode && !_cancleChanges)
            {
                MDSnackbarUnsavedChanges.IsActive = true;
                MDSnackbarMessage.Content = "Данные обновлены";
                MDSnackbarMessage.ActionContent = "ОК";
            }
        }
        private void SnackbarMessage_ActionClick(object sender, RoutedEventArgs e)
        {
            MDSnackbarUnsavedChanges.IsActive=false;
            _cancleChanges = true;
            Close();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSave_Click_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
